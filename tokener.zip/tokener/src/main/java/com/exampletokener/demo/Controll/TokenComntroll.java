package com.exampletokener.demo.Controll;

//import com.sun.org.apache.xml.internal.security.algorithms.SignatureAlgorithm;
import com.exampletokener.demo.Repo.TokenRepo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;

@RestController
@RequestMapping(path = "/token")
public class TokenComntroll {

    private TokenRepo tokenRepo;

    public int JWT_TOKEN_VALIDITY=60*60;

    private String auth="auth";
    private String scope="jj";

    @RequestMapping(path = "/hello")
    public String hi()
    {
        return "hi";
    }

   @RequestMapping(path = "/gettoken")
    public String generateToken(int id) throws NullPointerException
    {
        String jwt = Jwts.builder()
                .setSubject(auth)
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
                .claim("userId", Long.toString(id))
                .claim("scope", scope)
                .signWith(
                        SignatureAlgorithm.HS256,
                        "appSecret"
                )
                .compact();

        return jwt;
    }

    @RequestMapping(path = "/getclaims")
    public Jws<Claims> getclaimfromtoken(String token)
    {
        return Jwts.parser().setSigningKey("appSecret").parseClaimsJws(token);

    }
}
