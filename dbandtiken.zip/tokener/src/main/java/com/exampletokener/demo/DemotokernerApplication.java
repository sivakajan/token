package com.exampletokener.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemotokernerApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemotokernerApplication.class, args);
    }

}
